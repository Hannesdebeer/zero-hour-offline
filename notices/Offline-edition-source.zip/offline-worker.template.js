/* Modified offline edition, 2026-10-26. GPL-3.0-or-later with upstream notices. */
'use strict';
const VERSION = __VERSION__;
const MANIFEST = __MANIFEST__;
const BASE = new URL('./',self.location.href);
const PREFIX = 'zero-hour-complete-engine-' + encodeURIComponent(BASE.pathname) + '-';
const CACHE = PREFIX + VERSION;
const PATHS = new Map(MANIFEST.map(item=>[new URL(item.path,BASE).pathname,item]));
const HEADERS = __HEADERS__;
const hex = bytes=>[...new Uint8Array(bytes)].map(n=>n.toString(16).padStart(2,'0')).join('');
async function checked(response,item) {
  if(!response || !response.ok || response.type==='opaque') throw new Error('Missing engine file: '+item.path);
  const bytes=await response.clone().arrayBuffer();
  if(bytes.byteLength!==item.bytes || hex(await crypto.subtle.digest('SHA-256',bytes))!==item.sha256) throw new Error('Engine checksum mismatch: '+item.path);
  return response;
}
function isolated(response) {
  const headers=new Headers(response.headers);
  // fetch() exposes decoded bodies; do not preserve transport compression lengths.
  headers.delete('Content-Encoding');headers.delete('Content-Length');headers.delete('Transfer-Encoding');
  for(const [key,value] of Object.entries(HEADERS))headers.set(key,value);
  return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
}
self.addEventListener('install',event=>event.waitUntil((async()=>{
  // A version is usable only when all files and the final completion marker exist.
  // A failed installation never activates over the previous working worker.
  const cache=await caches.open(CACHE);
  await cache.delete(new URL('__complete',BASE));
  try {
    for(const item of MANIFEST) {
      const url=new URL(item.path,BASE);
      const response=await checked(await fetch(url,{cache:'reload',credentials:'omit'}),item);
      await cache.put(url,isolated(response));
    }
    await cache.put(new URL('__complete',BASE),new Response(VERSION));
  } catch(error) { await caches.delete(CACHE);throw error; }
  // Do not skipWaiting: updates wait until every client of the previous version closes.
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);
  if((await (await cache.match(new URL('__complete',BASE)))?.text())!==VERSION)throw new Error('Incomplete offline version');
  // Scope this cleanup exclusively to caches created by this edition.
  for(const key of await caches.keys()) if(key.startsWith(PREFIX)&&key!==CACHE)await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(url.origin!==BASE.origin){event.respondWith(Promise.resolve(new Response('External requests disabled',{status:403})));return;}
  if(event.request.method!=='GET' && event.request.method!=='HEAD'){event.respondWith(Promise.resolve(new Response('Uploads disabled',{status:405})));return;}
  // Only a local development server exposes these uncached test fixtures.
  if(['127.0.0.1','localhost'].includes(BASE.hostname)&&url.pathname.startsWith(BASE.pathname+'__test/'))return;
  event.respondWith((async()=>{
    if(url.pathname===BASE.pathname+'__cnc_https_info')return isolated(new Response('{"httpsEnabled":false}',{headers:{'Content-Type':'application/json'}}));
    if(url.pathname===BASE.pathname || url.pathname===BASE.pathname+'harness/play.html')url.pathname=BASE.pathname+'index.html';
    if(!PATHS.has(url.pathname))return new Response('Not included in this offline edition',{status:404});
    url.search='';url.hash='';
    const response=await (await caches.open(CACHE)).match(url);
    if(!response)return new Response('Offline engine file missing. Reconnect and prepare the engine again.',{status:503});
    if(event.request.method==='HEAD')return new Response(null,{status:response.status,headers:response.headers});
    return response;
  })());
});
self.addEventListener('message',event=>{
  if(event.data?.kind!=='verify-offline-cache'||!event.ports[0])return;
  event.waitUntil((async()=>{
    try {
      const cache=await caches.open(CACHE);
      if((await (await cache.match(new URL('__complete',BASE)))?.text())!==VERSION)throw new Error('Missing completion marker');
      for(const item of MANIFEST)await checked(await cache.match(new URL(item.path,BASE)),item);
      event.ports[0].postMessage({ok:true,version:VERSION,files:MANIFEST.length});
    } catch(error){event.ports[0].postMessage({ok:false,error:error.message});}
  })());
});

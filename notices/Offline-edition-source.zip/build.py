#!/usr/bin/env python3
"""Build the engine-only offline manifest. No downloads, game assets or tools."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
WEB=ROOT/'web'
HEADERS={
 'Cross-Origin-Opener-Policy':'same-origin',
 'Cross-Origin-Embedder-Policy':'require-corp',
 'Cross-Origin-Resource-Policy':'same-origin',
 'X-Content-Type-Options':'nosniff',
 'Content-Security-Policy':"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data: blob:; media-src 'self' data: blob:; worker-src 'self' blob:; font-src 'self' data:; object-src 'none'; frame-ancestors 'none'; form-action 'none'; base-uri 'self'",
}
def build():
 manifest=[]
 for path in sorted(WEB.rglob('*')):
  if path.is_symlink():raise RuntimeError('Symlink forbidden: '+str(path))
  if not path.is_file() or path.name in ['offline-worker.js','_headers']:continue
  if path.suffix.lower() in ['.big','.exe','.dll','.bin','.rar','.iso'] or 'game-data' in path.parts:raise RuntimeError('Game/payload file forbidden: '+str(path))
  data=path.read_bytes();manifest.append({'path':path.relative_to(WEB).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 template=(ROOT/'offline-worker.template.js').read_text()
 version=hashlib.sha256((json.dumps(manifest,sort_keys=True)+template+json.dumps(HEADERS,sort_keys=True)).encode()).hexdigest()[:20]
 worker=template.replace('__VERSION__',json.dumps(version)).replace('__MANIFEST__',json.dumps(manifest)).replace('__HEADERS__',json.dumps(HEADERS))
 (WEB/'offline-worker.js').write_text(worker)
 (WEB/'_headers').write_text('/*\n'+''.join('  '+k+': '+v+'\n' for k,v in HEADERS.items())+'\n/offline-worker.js\n  Cache-Control: no-cache\n  Service-Worker-Allowed: /\n')
 report={'version':version,'cached_files':len(manifest),'cached_bytes':sum(f['bytes'] for f in manifest),'files':manifest,'headers':HEADERS,'game_assets_included':False}
 (ROOT/'evidence'/'build-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k not in ['files','headers']}))
if __name__=='__main__':build()
